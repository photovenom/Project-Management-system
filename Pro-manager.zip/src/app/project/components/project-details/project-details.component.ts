import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { TaskListComponent } from "../../../task/components/task-list/task-list.component";
import { TaskFormComponent } from "../../../task/components/task-form/task-form.component";

@Component({
  selector: 'app-project-details',
  standalone: true,
  imports: [CommonModule, FormsModule, TaskListComponent, TaskFormComponent],
  templateUrl: './project-details.component.html',
  styleUrl: './project-details.component.css'
})
export class ProjectDetailsComponent implements OnInit {
  projectId!: number;

  constructor(private route: ActivatedRoute) {}

  ngOnInit(): void {
    this.projectId = Number(this.route.snapshot.paramMap.get('id'));
  }
}
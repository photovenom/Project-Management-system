import { Component } from '@angular/core';
import { ProjectService } from '../../services/project.service';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-project',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './add-project.component.html',
  styleUrl: './add-project.component.css'
})
export class CreateProjectComponent {
  project: any = {
    title: '',
    description: '',
    startDate: '',
    endDate: '',
    status: 'PLANNED',
    projectManagerId: 1 
  };

  constructor(private projectService: ProjectService) {}

  createProject(): void {
    this.projectService.createProject(this.project, this.project.projectManagerId)
      .subscribe(() => {
        alert('Project Created Successfully!');
      });
  }
}
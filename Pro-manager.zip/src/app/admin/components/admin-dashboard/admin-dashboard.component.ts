import { Component, OnInit } from '@angular/core';
import { AdminService } from '../../services/admin.service';
import { CommonModule } from '@angular/common';
import { Chart } from 'chart.js';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-admin-dashboard',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './admin-dashboard.component.html',
  styleUrl: './admin-dashboard.component.css'
})
export class AdminDashboardComponent implements OnInit {
  users: any[] = [];
  projects: any[] = [];
  tasks: any[] = [];
  stats: any = {};

  constructor(private adminService: AdminService, private http:HttpClient) {}

  ngOnInit() {
    this.loadDashboard();
  }

  loadDashboard() {
    this.adminService.getUsers().subscribe((resp) => (this.users = resp));
    this.adminService.getProjects().subscribe((resp) => (this.projects = resp));
    this.adminService.getTasks().subscribe((resp) => (this.tasks = resp));
    this.adminService.getDashboardStats().subscribe((resp) => {
      this.stats = resp;
      this.loadCharts();
    });
  }

  loadCharts() {
    new Chart('tasksChart', {
      type: 'pie',
      data: {
        labels: ['Completed', 'Pending'],
        datasets: [
          {
            data: [this.stats.completedTasks, this.stats.totalTasks - this.stats.completedTasks],
            backgroundColor: ['#4CAF50', '#FF5722'],
          },
        ],
      },
    });

    new Chart('projectsChart', {
      type: 'bar',
      data: {
        labels: ['Total Projects'],
        datasets: [
          {
            label: 'Projects',
            data: [this.stats.totalProjects],
            backgroundColor: ['#42A5F5'],
          },
        ],
      },
    });
  }
  loadTaskCompletionTrends() {
  this.http.get<any>('http://localhost:8080/api/reports/task-trends').subscribe(data => {
    new Chart('taskTrendChart', {
      type: 'line',
      data: {
        labels: data.labels,
        datasets: [{
          label: 'Task Completion Trends',
          data: data.values,
          borderColor: '#28a745',
          fill: false
        }]
      }
    });
  });
}

}
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-reports',
  standalone: true,
  imports: [FormsModule, CommonModule],
  templateUrl: './reports.component.html',
  styleUrl: './reports.component.css'
})
export class ReportsComponent {
  startDate: string = '';
  endDate: string = '';
  status: string = '';

  constructor(private http: HttpClient) {}

  filterReports() {
    console.log(`Filtering reports from ${this.startDate} to ${this.endDate} with status ${this.status}`);
  }

  downloadPdf() {
    this.http.get('http://localhost:8080/api/reports/pdf', { responseType: 'blob' })
      .subscribe(response => {
        const blob = new Blob([response], { type: 'application/pdf' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'Project_Report.pdf';
        a.click();
      });
  }

  downloadExcel() {
    this.http.get('http://localhost:8080/api/reports/excel', { responseType: 'blob' })
      .subscribe(response => {
        const blob = new Blob([response], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'Project_Report.xlsx';
        a.click();
      });
  }
}
import { Injectable } from '@angular/core';
import { Client } from '@stomp/stompjs';
import SockJS from 'sockjs-client';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class WebSocketService {
  private stompClient!: Client;
  private notificationSubject = new BehaviorSubject<string>('');
  notifications$: Observable<string> = this.notificationSubject.asObservable();

  constructor() {
    this.connect();
  }

  private connect() {
    const serverUrl = 'http://localhost:8080/ws';
    const socket = new SockJS(serverUrl);

    this.stompClient = new Client({
      webSocketFactory: () => socket,
      reconnectDelay: 5000, // Auto-reconnect every 5 seconds
      debug: (msg) => console.log(msg),
    });

    this.stompClient.onConnect = () => {
      console.log('✅ Connected to WebSocket Server');
      this.stompClient.subscribe('/topic/notifications', (message) => {
        this.notificationSubject.next(message.body);
      });
    };

    this.stompClient.activate();
  }

  sendMessage(message: string) {
    if (this.stompClient.connected) {
      this.stompClient.publish({ destination: '/app/send', body: message });
    }
  }
}

import { Routes } from '@angular/router';
import { LoginComponent } from './auth/components/login/login.component';
import { RegisterComponent } from './auth/components/register/register.component';
import { ProjectListComponent } from './project/components/project-list/project-list.component';
import { CreateProjectComponent } from './project/components/add-project/add-project.component';
import { ProjectDetailsComponent } from './project/components/project-details/project-details.component';
import { TaskListComponent } from './task/components/task-list/task-list.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { TaskFormComponent } from './task/components/task-form/task-form.component';
import { DocumentUploadComponent } from './document/components/document-upload/document-upload.component';
import { DocumentListComponent } from './document/components/document-list/document-list.component';
import { AdminDashboardComponent } from './admin/components/admin-dashboard/admin-dashboard.component';
import { ReportsComponent } from './components/reports/reports.component';
import { AuthGuard } from './guards/auth.guard';
import { NotificationsComponent } from './components/notifications/notifications.component';
import { RoleGuard } from './guards/role.guard';

export const routes: Routes = [
  { path: '', redirectTo: '/login', pathMatch: 'full' },
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },

  // User Dashboard
  { path: 'dashboard', component: DashboardComponent, canActivate: [AuthGuard] },

  // Project Management Routes
  { path: 'projects', component: ProjectListComponent, canActivate: [AuthGuard] },
  { path: 'projects/:id', component: ProjectDetailsComponent, canActivate: [AuthGuard] },
  { path: 'projects/create', component: CreateProjectComponent, canActivate: [AuthGuard] },

  // Task Management Routes
  { path: 'projects/:id/tasks', component: TaskListComponent, canActivate: [AuthGuard] },
  { path: 'projects/:id/tasks/create', component: TaskFormComponent, canActivate: [AuthGuard] },

  // Document Sharing Routes
  { path: 'projects/:id/documents', component: DocumentListComponent, canActivate: [AuthGuard] },
  { path: 'projects/:id/documents/upload', component: DocumentUploadComponent, canActivate: [AuthGuard] },

  // Collaboration Routes (Comments & Notifications)
  // { path: 'projects/:id/comments', component: CommentsComponent, canActivate: [AuthGuard] },
  { path: 'notifications', component: NotificationsComponent, canActivate: [AuthGuard] },

  // Admin Dashboard (Only accessible to Admins)
  { path: 'admin', component: AdminDashboardComponent, canActivate: [AuthGuard, RoleGuard], data: { roles: ['ADMIN'] } },
  { path: 'reports', component: ReportsComponent, canActivate: [AuthGuard] },

  // Wildcard Route for 404 Not Found
  { path: '**', redirectTo: '/dashboard' }
];

import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DocumentService {

  private baseUrl = 'http://localhost:8080/api/documents';

  constructor(private http: HttpClient) { }

  uploadFile(projectId: number, file: File): Observable<any> {
    const formData: FormData = new FormData();
    formData.append('file', file);
    return this.http.post(`${this.baseUrl}/upload/${projectId}`, formData);
  }

  getProjectDocuments(projectId: number): Observable<any> {
    return this.http.get(`${this.baseUrl}/project/${projectId}`);
  }

  downloadFile(documentId: number): Observable<Blob> {
    return this.http.get(`${this.baseUrl}/download/${documentId}`, { responseType: 'blob' });
  }

  deleteFile(documentId: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/${documentId}`);
  }
}

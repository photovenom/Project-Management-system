import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DocumentService } from '../../service/document.service';

@Component({
  selector: 'app-document-upload',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './document-upload.component.html',
  styleUrl: './document-upload.component.css'
})
export class DocumentUploadComponent {
  selectedFile!: File | null;
  uploadMessage!: string;
  projectId = 1; 

  constructor(private documentService: DocumentService) {}

  onFileSelected(event: any) {
    this.selectedFile = event.target.files[0] ?? null;
  }

  uploadFile() {
    if (this.selectedFile) {
      this.documentService.uploadFile(this.projectId, this.selectedFile).subscribe({
        next: () => {
          this.uploadMessage = 'File uploaded successfully!';
          this.selectedFile = null;
        },
        error: () => {
          this.uploadMessage = 'Failed to upload file';
        }
      });
    }
  }
}

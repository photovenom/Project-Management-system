import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { DocumentService } from '../../service/document.service';


@Component({
  selector: 'app-document-list',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './document-list.component.html',
  styleUrl: './document-list.component.css'
})
export class DocumentListComponent implements OnInit {
  documents: any[] = [];
  projectId = 1; 

  constructor(private documentService: DocumentService) {}

  ngOnInit() {
    this.loadDocuments();
  }

  loadDocuments() {
    this.documentService.getProjectDocuments(this.projectId).subscribe(data => {
      this.documents = data;
    });
  }


  downloadFile(documentId: number) {
    this.documentService.downloadFile(documentId).subscribe(response => {
      const blob = new Blob([response], { type: 'application/octet-stream' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = this.documents.find(doc => doc.id === documentId)?.fileName;
      a.click();
      window.URL.revokeObjectURL(url);
    });
  }

  deleteFile(documentId: number) {
    this.documentService.deleteFile(documentId).subscribe(() => {
      this.documents = this.documents.filter(doc => doc.id !== documentId);
    });
  }
}

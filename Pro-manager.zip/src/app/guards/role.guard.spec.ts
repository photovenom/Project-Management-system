import { TestBed } from '@angular/core/testing';
import { CanActivateFn } from '@angular/router';

import { RoleGuard } from './role.guard';

describe('RoleGuard', () => {
  let guard: RoleGuard;
  
  beforeEach(() => {
      TestBed.configureTestingModule({
        providers: [RoleGuard]
      });
      guard = TestBed.inject(RoleGuard);
    });

  it('should be created', () => {
    expect(guard).toBeTruthy();
  });
});

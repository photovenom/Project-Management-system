import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class TaskService {
  private apiUrl = 'http://localhost:8080/api/tasks';

  constructor(private http: HttpClient) {}

  getTasksByProject(projectId: number): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/project/${projectId}`);
  }

  createTask(task: any, projectId: number, userId: number): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/create/${projectId}/${userId}`, task);
  }

  updateTaskStatus(taskId: number, status: string): Observable<void> {
    return this.http.put<void>(`${this.apiUrl}/update-status/${taskId}?status=${status}`, {});
  }
}

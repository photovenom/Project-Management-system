import { Component, Input } from '@angular/core';
import { TaskService } from '../../services/task.service';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-task-form',
  standalone: true,
  imports: [FormsModule, CommonModule, ReactiveFormsModule],
  templateUrl: './task-form.component.html',
  styleUrl: './task-form.component.css'
})
export class TaskFormComponent {
  @Input() projectId!: number;
  taskForm: FormGroup;

  constructor(private fb: FormBuilder, private taskService: TaskService) {
    this.taskForm = this.fb.group({
      title: ['', [Validators.required, Validators.minLength(5)]],
      description: ['', Validators.required],
      status: ['TODO', Validators.required],
      assignedUserId: [null, Validators.required]
    });
  }

  createTask(): void {
    if (this.taskForm.invalid) {
      alert('Please fill in all fields correctly.');
      return;
    }

    this.taskService.createTask(this.taskForm.value, this.projectId, this.taskForm.value.assignedUserId)
      .subscribe({
        next: () => alert('Task Created Successfully!'),
        error: (err) => alert(`Error: ${err.message}`)
      });
  }
}
import { Component, Input, OnInit, inject } from '@angular/core';
import { TaskService } from '../../services/task.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Client } from '@stomp/stompjs';
import SockJS from 'sockjs-client';


@Component({
  selector: 'app-task-list',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './task-list.component.html',
  styleUrl: './task-list.component.css'
})
export class TaskListComponent implements OnInit {
  @Input() projectId!: number; // Task list is loaded based on a project ID
  tasks: any[] = [];
  private stompClient: Client = new Client;

  private taskService = inject(TaskService);

  ngOnInit(): void {
    this.loadTasks();
    this.connectWebSocket();
  }

  loadTasks(): void {
    this.taskService.getTasksByProject(this.projectId).subscribe((data) => {
      this.tasks = data;
    });
  }

  updateStatus(taskId: number, newStatus: string): void {
    this.taskService.updateTaskStatus(taskId, newStatus).subscribe(() => {
      this.loadTasks();
    });
  }

  connectWebSocket(): void {
    this.stompClient = new Client({
      webSocketFactory: () => new SockJS('http://localhost:8080/ws'),
      debug: (str) => console.log(str),
      onConnect: () => {
        console.log('Connected to WebSocket');
        this.stompClient.subscribe('/topic/task-updates', (message) => {
          const updatedTask = JSON.parse(message.body);
          this.updateTaskList(updatedTask);
        });
      },
    });
    this.stompClient.activate();
  }

  updateTaskList(updatedTask: any): void {
    const index = this.tasks.findIndex(task => task.id === updatedTask.id);
    if (index !== -1) {
      this.tasks[index] = updatedTask;
    } else {
      this.tasks.push(updatedTask);
    }
  }
}

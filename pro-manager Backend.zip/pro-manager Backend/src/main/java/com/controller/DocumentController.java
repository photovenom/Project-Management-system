package com.controller;

import com.model.Document;
import com.model.Project;
import com.model.User;
import com.service.DocumentService;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

@CrossOrigin("*")
@RestController
@RequestMapping("/documents")
public class DocumentController {

    private final DocumentService documentService;

    public DocumentController(DocumentService documentService) {
        this.documentService = documentService;
    }
    @PreAuthorize("hasAnyRole('PROJECT_MANAGER', 'TEAM_MEMBER')")
    @PostMapping("/upload")
    public ResponseEntity<Document> uploadDocument(
    		@RequestParam("file") MultipartFile file,
    		@RequestParam("projectId") Long projectId,
            @RequestParam("userId") Long userId) {
        try {
            Project project = new Project();
            project.setId(projectId);

            User user = new User();
            user.setId(userId);

            Document savedDocument = documentService.uploadDocument(file, project, user);
            return ResponseEntity.ok(savedDocument);
        } catch (IOException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }

    @GetMapping("/project/{projectId}")
    public ResponseEntity<List<Document>> getDocumentsByProject(@PathVariable Long projectId) {
        return ResponseEntity.ok(documentService.getDocumentsByProject(projectId));
    }

    @GetMapping("/{id}")
    public ResponseEntity<byte[]> downloadDocument(@PathVariable Long id) {
        Optional<Document> documentOpt = documentService.getDocumentById(id);
        if (documentOpt.isPresent()) {
            Document document = documentOpt.get();
            return ResponseEntity.ok()
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=" + document.getFileName())
                    .contentType(org.springframework.http.MediaType.parseMediaType(document.getFileType()))
                    .body(document.getFileData());
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }
    }
}

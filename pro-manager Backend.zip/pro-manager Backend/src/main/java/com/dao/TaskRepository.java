package com.dao;

import com.model.Task;

import jakarta.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

@Transactional
public interface TaskRepository extends JpaRepository<Task, Long> {
    List<Task> findByProjectId(Long projectId);
    List<Task> findByAssignedToId(Long userId);
    @Modifying
    @Query("DELETE FROM Task t WHERE t.assignedTo.id = :userId")
    void deleteByAssignedToId(@Param("userId") Long userId);
}

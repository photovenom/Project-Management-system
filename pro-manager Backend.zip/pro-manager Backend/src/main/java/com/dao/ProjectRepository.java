package com.dao;


import jakarta.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.model.Project;

import java.util.List;

@Transactional
public interface ProjectRepository extends JpaRepository<Project, Long> {
    List<Project> findByProjectManagerId(Long managerId);
}

package com.util;

import com.service.CustomUserDetailsService;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.JwtException;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
import org.springframework.util.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

@Component
public class JwtFilter extends OncePerRequestFilter {

    private static final Logger logger = LoggerFactory.getLogger(JwtFilter.class);

    private final JwtUtil jwtUtil;
    private final CustomUserDetailsService userDetailsService;

    public JwtFilter(JwtUtil jwtUtil, CustomUserDetailsService userDetailsService) {
        this.jwtUtil = jwtUtil;
        this.userDetailsService = userDetailsService;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
            throws ServletException, IOException {

        String requestURI = request.getRequestURI();

        // Skip JWT authentication for public endpoints
        if (requestURI.equals("/auth/login") || requestURI.equals("/auth/register")) {
            logger.info("Skipping JWT filter for public endpoint: {}", requestURI);
            chain.doFilter(request, response);
            return;
        }

        // If already authenticated, skip JWT validation
        if (SecurityContextHolder.getContext().getAuthentication() != null) {
            chain.doFilter(request, response);
            return;
        }

        try {
            String token = extractJwtFromRequest(request);

            if (!StringUtils.hasText(token)) {
                logger.warn("No JWT token found in request");
            } else {
                logger.info("Extracted JWT Token: {}", token);

                String email = jwtUtil.extractEmail(token);
                if (email == null) {
                    logger.warn("Unable to extract email from JWT token");
                } else {
                    logger.info("Extracted Email from Token: {}", email);

                    UserDetails userDetails = userDetailsService.loadUserByUsername(email);
                    if (userDetails != null && jwtUtil.validateToken(token, userDetails)) {
                        setAuthentication(token, userDetails, request);
                    } else {
                        logger.warn("Invalid or expired JWT token for user: {}", email);
                    }
                }
            }
        } catch (ExpiredJwtException ex) {
            logger.error("JWT Expired: {}", ex.getMessage());
        } catch (JwtException ex) {
            logger.error("JWT Processing Error: {}", ex.getMessage());
        } catch (Exception ex) {
            logger.error("Unexpected error in JWT Filter: {}", ex.getMessage());
        }

        chain.doFilter(request, response);
    }

    private String extractJwtFromRequest(HttpServletRequest request) {
        String bearerToken = request.getHeader("Authorization");
        if (StringUtils.hasText(bearerToken) && bearerToken.startsWith("Bearer ")) {
            return bearerToken.substring(7);
        }
        return null;
    }

    private void setAuthentication(String token, UserDetails userDetails, HttpServletRequest request) {
        List<String> roles = jwtUtil.extractRoles(token); // Extract roles from token

        List<GrantedAuthority> authorities = roles.stream()
                .map(SimpleGrantedAuthority::new)
                .collect(Collectors.toList());

        UsernamePasswordAuthenticationToken authToken =
                new UsernamePasswordAuthenticationToken(userDetails, null, authorities);
        authToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
        SecurityContextHolder.getContext().setAuthentication(authToken);

        logger.info("User authenticated successfully: {}", userDetails.getUsername());
        logger.info("Extracted Roles: {}", roles);
    }
}

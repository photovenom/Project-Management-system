package com.dto;

import lombok.Data;

@Data
public class CommentRequest {
	private String text;
    private Long taskId;
    private Long userId;
    
    public CommentRequest() {
		// TODO Auto-generated constructor stub
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public Long getTaskId() {
		return taskId;
	}

	public void setTaskId(Long taskId) {
		this.taskId = taskId;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public CommentRequest(String text, Long taskId, Long userId) {
		super();
		this.text = text;
		this.taskId = taskId;
		this.userId = userId;
	}

}

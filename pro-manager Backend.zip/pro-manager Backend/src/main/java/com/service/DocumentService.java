package com.service;

import com.dao.DocumentRepository;
import com.model.Document;
import com.model.Project;
import com.model.User;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class DocumentService {

    private final DocumentRepository documentRepository;

    public DocumentService(DocumentRepository documentRepository) {
        this.documentRepository = documentRepository;
    }

    public Document uploadDocument(MultipartFile file, Project project, User user) throws IOException {
        Document document = new Document();
        document.setFileName(file.getOriginalFilename());
        document.setFileType(file.getContentType());
        document.setUploadDate(LocalDateTime.now());
        document.setFileData(file.getBytes());
        document.setProject(project);
        document.setUploadedBy(user);
        return documentRepository.save(document);
    }

    public List<Document> getDocumentsByProject(Long projectId) {
        return documentRepository.findByProjectId(projectId);
    }

    public Optional<Document> getDocumentById(Long id) {
        return documentRepository.findById(id);
    }
}
